# Last Mile Roleplay — Community Development Dashboard

A GitHub Pages-ready, static public development roadmap.

## Publish
1. Create a new **public** GitHub repository, for example `last-mile-roleplay-roadmap`.
2. Upload `index.html` and `.nojekyll` to the repository's root directory (you can also upload this README).
3. Commit the files to the `main` branch.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**. Select `main` and `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish. The site will normally appear at `https://YOUR-USERNAME.github.io/last-mile-roleplay-roadmap/`.

## Updating the site
Edit or replace `index.html` and commit the change to the same branch. GitHub Pages will redeploy.

## Important
- This is the **public-only** dashboard. Do not upload the separate developer dashboard to a public repository.
- This is a static snapshot. Updating the developer dashboard on your computer does not automatically update the public site. Use the developer panel's **Download public site** feature, rename that file to `index.html`, and commit it to the repository.
- GitHub Pages is public hosting, not an authenticated admin backend.
